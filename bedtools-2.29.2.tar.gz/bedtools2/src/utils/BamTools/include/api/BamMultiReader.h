#include <htslib/sam.h>
#include <string>
#include  <vector>
#include <BamReader.hpp>
namespace BamTools{
	typedef BamReader BamMultiReader;
}
